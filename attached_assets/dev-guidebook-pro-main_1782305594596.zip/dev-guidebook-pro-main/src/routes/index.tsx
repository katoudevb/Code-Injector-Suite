import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, BookOpen, Search, WifiOff, Code2 } from "lucide-react";
import * as Icons from "lucide-react";
import { sections } from "@/data";
import { TechTag } from "@/components/docs/TechTag";

function DynIcon({ name }: { name: string }) {
  const lib = Icons as unknown as Record<
    string,
    React.ComponentType<{ className?: string }>
  >;
  const Cmp = lib[name] ?? BookOpen;
  return <Cmp className="h-5 w-5" />;
}

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "DevDocs — Référence du développement web en français" },
      {
        name: "description",
        content:
          "Référence personnelle complète et hors-ligne du développement web : HTML, CSS, JavaScript, TypeScript, React, Next.js, Vue, Angular, Node, PHP, SQL, Docker et plus.",
      },
      { property: "og:title", content: "DevDocs — Référence du développement web" },
      {
        property: "og:description",
        content:
          "Référence développeur en français avec exemples de code commentés ligne par ligne.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  const totalSub = sections.reduce((n, s) => n + s.subsections.length, 0);

  return (
    <div className="min-h-dvh bg-background text-foreground">
      {/* En-tête */}
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
          <div className="flex items-center gap-2 font-bold">
            <BookOpen className="h-5 w-5 text-primary" />
            <span>DevDocs</span>
          </div>
          <Link
            to="/docs"
            className="inline-flex items-center gap-1.5 rounded-md bg-primary px-3.5 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
          >
            Ouvrir la documentation
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="mx-auto max-w-3xl px-5 py-16 text-center sm:py-24">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary px-3 py-1 text-xs font-medium text-muted-foreground">
          <WifiOff className="h-3.5 w-3.5" /> Disponible hors-ligne
        </span>
        <h1 className="mt-6 text-3xl font-bold leading-tight sm:text-5xl">
          Ta référence du développement web,
          <span className="text-primary"> en français.</span>
        </h1>
        <p className="mx-auto mt-5 max-w-xl text-base text-muted-foreground sm:text-lg">
          Une documentation personnelle et complète : HTML, CSS, JavaScript et
          bien plus, avec des exemples de code commentés ligne par ligne.
        </p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link
            to="/docs"
            className="inline-flex items-center gap-1.5 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
          >
            Commencer à explorer
            <ArrowRight className="h-4 w-4" />
          </Link>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>{sections.length} technologies</span>
            <span>·</span>
            <span>{totalSub} chapitres</span>
          </div>
        </div>
      </section>

      {/* Atouts */}
      <section className="mx-auto grid max-w-5xl gap-4 px-5 sm:grid-cols-3">
        {[
          { icon: Code2, t: "Exemples commentés", d: "Du code clair, expliqué ligne par ligne." },
          { icon: Search, t: "Recherche instantanée", d: "Filtre les sections en temps réel." },
          { icon: WifiOff, t: "100% hors-ligne", d: "Consultable partout, sans connexion." },
        ].map(({ icon: Icon, t, d }) => (
          <div key={t} className="rounded-lg border border-border bg-secondary/40 p-5">
            <Icon className="h-5 w-5 text-primary" />
            <h3 className="mt-3 font-semibold">{t}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{d}</p>
          </div>
        ))}
      </section>

      {/* Technologies */}
      <section className="mx-auto max-w-6xl px-5 py-16">
        <h2 className="mb-6 text-xl font-bold">Explorer par technologie</h2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {sections.map((s) => (
            <Link
              key={s.id}
              to="/docs"
              search={{ s: s.id }}
              className="group flex items-center justify-between rounded-lg border border-border bg-secondary/30 p-4 transition-colors hover:border-primary/50 hover:bg-secondary"
            >
              <div className="flex min-w-0 items-center gap-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
                  <DynIcon name={s.icon} />
                </span>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{s.title}</span>
                    {s.tags[0] && <TechTag tech={s.tags[0]} />}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {s.subsections.length} chapitres
                  </p>
                </div>
              </div>
              <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:text-primary" />
            </Link>
          ))}
        </div>
      </section>

      <footer className="border-t border-border">
        <div className="mx-auto max-w-6xl px-5 py-6 text-sm text-muted-foreground">
          DevDocs · Documentation personnelle de développement web
        </div>
      </footer>
    </div>
  );
}
