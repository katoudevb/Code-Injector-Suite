import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ChevronRight, Menu, X } from "lucide-react";
import { sections } from "@/data";
import { Sidebar } from "@/components/docs/Sidebar";
import { ContentRenderer } from "@/components/docs/ContentRenderer";
import { TechTag } from "@/components/docs/TechTag";

export const Route = createFileRoute("/docs")({
  validateSearch: (search: Record<string, unknown>) => ({
    s: typeof search.s === "string" ? search.s : undefined,
  }),
  head: () => ({
    meta: [
      { title: "DevDocs — Documentation développement web" },
      {
        name: "description",
        content:
          "Référence personnelle complète et hors-ligne du développement web : HTML, CSS, JavaScript, TypeScript, React, Next.js, Vue, Angular, Node, PHP, SQL, Docker et plus.",
      },
      { property: "og:title", content: "DevDocs — Documentation développement web" },
      {
        property: "og:description",
        content:
          "Référence développeur en français avec exemples de code commentés ligne par ligne.",
      },
    ],
  }),
  component: DocsApp,
});

function DocsApp() {
  const { s } = Route.useSearch();
  const initial = sections.find((sec) => sec.id === s) ?? sections[0];
  const [activeSection, setActiveSection] = useState(initial.id);
  const [activeSub, setActiveSub] = useState(initial.subsections[0].id);
  const [mobileOpen, setMobileOpen] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);

  const section = sections.find((s) => s.id === activeSection) ?? sections[0];
  const sub =
    section.subsections.find((s) => s.id === activeSub) ?? section.subsections[0];

  const select = (sectionId: string, subId: string) => {
    setActiveSection(sectionId);
    setActiveSub(subId);
    setMobileOpen(false);
  };

  useEffect(() => {
    contentRef.current?.scrollTo({ top: 0, behavior: "smooth" });
  }, [activeSection, activeSub]);

  return (
    <div className="flex h-dvh overflow-hidden bg-background">
      {/* Sidebar desktop */}
      <aside className="hidden w-[260px] shrink-0 border-r border-border md:block">
        <Sidebar
          sections={sections}
          activeSection={activeSection}
          activeSub={activeSub}
          onSelect={select}
        />
      </aside>

      {/* Sidebar mobile (drawer) */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div
            className="absolute inset-0 bg-black/60"
            onClick={() => setMobileOpen(false)}
          />
          <div className="absolute left-0 top-0 h-full w-[280px] border-r border-border">
            <Sidebar
              sections={sections}
              activeSection={activeSection}
              activeSub={activeSub}
              onSelect={select}
            />
          </div>
        </div>
      )}

      {/* Zone de contenu */}
      <div ref={contentRef} className="flex-1 overflow-y-auto">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-border bg-background/90 px-5 py-3 backdrop-blur">
          <button
            onClick={() => setMobileOpen((o) => !o)}
            className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary md:hidden"
            aria-label="Menu"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
          {/* Fil d'Ariane */}
          <nav className="flex min-w-0 items-center gap-1.5 text-sm">
            <span className="shrink-0 text-muted-foreground">{section.title}</span>
            <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground/60" />
            <span className="truncate font-medium text-foreground">{sub.title}</span>
          </nav>
        </header>

        <main className="mx-auto max-w-3xl px-4 py-6 sm:px-5 sm:py-8">
          <div className="mb-2 flex items-center gap-2">
            {section.tags.map((t) => (
              <TechTag key={t} tech={t} />
            ))}
          </div>
          <h1 className="mb-1 text-2xl font-bold text-foreground sm:text-3xl">{sub.title}</h1>
          <p className="mb-6 text-sm text-muted-foreground">
            {section.title} · Documentation
          </p>
          <ContentRenderer blocks={sub.blocks} />

          <div className="mt-12 flex flex-wrap justify-between gap-3 border-t border-border pt-6">
            <PrevNext
              section={section}
              subId={sub.id}
              onSelect={select}
            />
          </div>
        </main>
      </div>
    </div>
  );
}

function PrevNext({
  section,
  subId,
  onSelect,
}: {
  section: (typeof sections)[number];
  subId: string;
  onSelect: (s: string, sub: string) => void;
}) {
  const idx = section.subsections.findIndex((s) => s.id === subId);
  const prev = section.subsections[idx - 1];
  const next = section.subsections[idx + 1];
  return (
    <>
      <div>
        {prev && (
          <button
            onClick={() => onSelect(section.id, prev.id)}
            className="text-sm text-muted-foreground hover:text-primary"
          >
            ← {prev.title}
          </button>
        )}
      </div>
      <div>
        {next && (
          <button
            onClick={() => onSelect(section.id, next.id)}
            className="text-sm text-muted-foreground hover:text-primary"
          >
            {next.title} →
          </button>
        )}
      </div>
    </>
  );
}
